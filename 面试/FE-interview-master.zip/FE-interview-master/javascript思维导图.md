# JS思维导图汇总
-----------------------------

## 1.JavaScript变量

![](http://images.cnitblog.com/blog/608782/201409/031424088288890.gif)

## 2.JavaScript运算符

![](http://images.cnitblog.com/blog/608782/201409/031425524532800.gif)

## 3.JavaScript数组

![](http://images.cnitblog.com/blog/608782/201409/031426347503011.gif)

## 4.JavaScript流程语句

![](http://images.cnitblog.com/blog/608782/201409/031427375004707.gif)

## 5.JavaScript字符串函数

![](http://images.cnitblog.com/blog/608782/201409/031428564386592.gif)

## 6.JavaScript函数基础

![](http://images.cnitblog.com/blog/608782/201409/031429317505536.gif)

## 7.JavaScript基础DOM操作

![](http://images.cnitblog.com/blog/608782/201409/031430098606493.gif)
![](http://images.cnitblog.com/blog2015/608782/201503/291310116771993.jpg)

## 8.JavaScript基础BOM操作

![](http://images.cnitblog.com/blog2015/608782/201503/291311256619962.jpg)
## 9.JavaScript正则表达式

![](http://images.cnitblog.com/blog/608782/201409/031430427829068.gif)
