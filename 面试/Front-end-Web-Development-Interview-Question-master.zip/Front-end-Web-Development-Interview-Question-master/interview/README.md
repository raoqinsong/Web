# 前端面经部分

1. [面试前端工程师](/interview/1.md) 
2. [知乎|web前端开发方向校招考什么](http://www.zhihu.com/question/26188893) :arrow_upper_right:
3. [知乎|腾讯web前端方向实习笔试准备](http://www.zhihu.com/question/20966351/answer/24401878) :arrow_upper_right:
4. [如何在面试中识别一个坏老板](http://get.jobdeer.com/6384.get/) :arrow_upper_right:
5. [谈谈面试与面试题](https://github.com/wintercn/blog/issues/4) @ [wintercn](https://github.com/wintercn) :arrow_upper_right:
6. [说说最近几次面试](http://www.cnblogs.com/yexiaochai/p/4366051.html) @ [叶小钗](http://weibo.com/yiquinian) :arrow_upper_right:
7. [在LinkedIn做面试官的故事](https://baijia.baidu.com/s?old_id=52449) :arrow_upper_right:
8. [写给前端面试者](http://www.w3cplus.com/css/write-to-front-end-developer-interview.html) @大漠 :arrow_upper_right:
