## 简历怎么写?

1. [精益技术简历之道](http://www.cnblogs.com/figure9/p/lean-technical-resume.html) @ [peng_gong](http://weibo.com/pegong) :arrow_upper_right:
2. [如何写好技术简历 ](http://get.jobdeer.com/744.get) @ [easychen](https://github.com/easychen) :arrow_upper_right:
3. [Web 前端程序员简历模板](/resume/1) @ [easychen](https://github.com/easychen)
4. [吐嘈「个人简历」](http://mp.weixin.qq.com/s?__biz=MzA5NDY0ODkxNA==&mid=200168752&idx=1&sn=348edc7956f1ac9652aa2523b902bef5&scene=4) @ [rank](https://www.zhihu.com/people/rank) :arrow_upper_right:
5. [如何写打动人的「个人简历」](http://mp.weixin.qq.com/s?__biz=MzA5NDY0ODkxNA==&mid=200173772&idx=1&sn=895a5c66548c1b4a72153b2217350ca1&scene=4) @[rank](https://www.zhihu.com/people/rank) :arrow_upper_right:
 
 
 ## 简历生成
 
 - [使用 vue 生成漂亮的简历](https://github.com/salomonelli/best-resume-ever)
