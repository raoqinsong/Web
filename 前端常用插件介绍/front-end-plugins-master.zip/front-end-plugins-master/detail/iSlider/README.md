# [iSlider](https://github.com/BE-FE/iSlider)
iSlider是一个表现出众，无任何插件依赖的手机平台javascript滑动组件。它能够处理大多数的滑动场景，例如图片或者DOM元素。目前支持以下特性：

* 性能好，体积小，占用内存小，核心代码仅500行。
* 可以按需加载需要的功能。
* 丰富的动画效果。
* 可以设置回调函数(onslidestart, onslide, onslideend, onslidechange)。
* 支持滑动衰减效果，循环滑动，自动播放，水平/垂直切换。
* 支持图片预加载，改善用户体验。
* 支持图片的缩放。

Baidu出品