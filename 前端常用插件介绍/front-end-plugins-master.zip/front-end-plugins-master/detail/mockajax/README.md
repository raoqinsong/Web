# jquery-mockjax
[mock](http://baike.baidu.com/view/2445748.htm) ajax请求ajax请求。    
[Github](https://github.com/jakerella/jquery-mockjax)