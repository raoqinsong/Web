# 标签云
[官网](http://www.goat1000.com/tagcanvas.php) [Github](https://github.com/goat1000/TagCanvas)

## 特性
* 云的形状：垂直会水平转的圆柱体(cylinder)，环状，球形
* 标签内容：文本或图片
* 标签云的背景
* 标签被点击的事件