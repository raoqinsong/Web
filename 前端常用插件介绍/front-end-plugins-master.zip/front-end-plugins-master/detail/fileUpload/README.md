# 文件上传（jQuery-File-Upload）

版本 v5.40.1     
依赖jquery,jquery.ui.widget.js

后端有nodejs模拟了一个

## 运行
1. `npm install`
1. `node index.js`
1. 在浏览器中打开 `http://localhost:3000/`


[官网](https://github.com/blueimp/jQuery-File-Upload/)    