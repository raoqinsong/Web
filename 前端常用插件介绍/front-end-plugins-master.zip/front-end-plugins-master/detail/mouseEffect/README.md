# 超酷的jQuery跟随鼠标气泡动画
http://www.html5tricks.com/jquery-bubble-animation.html