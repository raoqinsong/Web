$(document).ready(function() {
	// http://slidesjs.com/
    $(".adplan-slide").slidesjs({
    });
});
