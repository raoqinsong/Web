# 高质量插件
选择的插件，review 插件的源码，并详细看其 API 和 写详尽的 Demo。

* 幻灯
* 分页
* 弹出框
* 验证
* alert/confirm
* data-grid
* lazyload
* 树
