## 还未分类的一些组件
* [formalize](http://formalize.me/) 让表单元素在不同系统的主流浏览器上，外观一致。
* [datedropper](http://felicegattuso.com/projects/datedropper/) 很清新的日历控件。IE9+
* [sprint](https://github.com/bendc/sprint) Sprint is an alternative—not a replacement—for jQuery. jQuery offers more features, handles more edge cases and supports more browsers. Sprint is just a thin layer making the DOM friendlier without sacrificing on performance.
* [Clusterize.js](https://github.com/NeXTs/Clusterize.js) 展示大量二维数据不卡顿
* [JSON Server](https://github.com/typicode/json-server) Get a full fake REST API with zero coding in less than 30 seconds (seriously)
* [Colorify.js](http://colorify.rocks/index.html) awesome~ 从图片中取颜色，基于这些颜色做一些事情。
* [mojs](https://github.com/legomushroom/mojs) 值得研究的一个动画库
* [svg to image](https://github.com/Jam3/svg-to-image) 把 svg 在 canvas 中画出来






