# Badge 标记
<div align="center">
  <img src="screenshot/basic.png" alt="外观"><br>
  <img src="screenshot/max.png" alt="外观"><br>
  <img src="screenshot/string.png" alt="外观"><br>
  <img src="screenshot/dot.png" alt="外观"><br>
</div>

## 功能
* 展示新消息数量。
* 自定义最大值。
* 显示数字以外的文本内容。
* 以红点的形式标注需要关注的内容。

## 实现的组件
* [Badge 标记](http://element-cn.eleme.io/#/zh-CN/component/badge) Element 的组件。




