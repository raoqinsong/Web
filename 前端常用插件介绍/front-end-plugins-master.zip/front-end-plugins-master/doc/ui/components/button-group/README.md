# 按钮组
<div align="center">
  <img src="screenshot/basic.png" alt="外观">
</div>

## 功能
* 多个按钮显示一行。

## 实现的组件
* [Button 按钮](http://element-cn.eleme.io/#/zh-CN/component/button) Element 的组件。



