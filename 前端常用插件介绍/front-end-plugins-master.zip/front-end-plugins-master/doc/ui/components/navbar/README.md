# NavBar
<div align="center">
  <img src="screenshot/basic.png" alt="外观">
</div>

## 别名
头部导航栏，顶部导航栏。

## 功能
* 左侧返回的箭头及点击回调。
* 中间的页面标题。
* 右侧的内容及点击回调。

## 实现的组件
* [NavBar](implement/vant-navbar) Vant 的组件。
* [header](implement/mint-header) Mint 的组件。




