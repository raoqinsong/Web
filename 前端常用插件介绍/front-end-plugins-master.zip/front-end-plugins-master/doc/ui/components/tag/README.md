# Tag 标签
<div align="center">
  <img src="screenshot/basic.png" alt="外观"><br>
  <img src="screenshot/edit.png" alt="外观"><br>
</div>

## 别名
Label。

## 功能
* 类型: success,info,warning,danger。
* 大小。
* 可移除。

## 实现的组件
* [Tag 标签](http://element-cn.eleme.io/#/zh-CN/component/tag) Element 的组件。




