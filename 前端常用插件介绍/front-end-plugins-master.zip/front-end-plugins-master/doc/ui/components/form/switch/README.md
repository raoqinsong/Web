# Switch 开关
<div align="center">
  <img src="screenshot/basic.png" alt="外观">
</div>

## 功能
* 禁用状态
* 开关处于打开状态时的文字
* 开关处于关闭状态时的文字

## 实现的组件
* [Switch 开关](http://element-cn.eleme.io/#/zh-CN/component/switch) Element 的组件。




