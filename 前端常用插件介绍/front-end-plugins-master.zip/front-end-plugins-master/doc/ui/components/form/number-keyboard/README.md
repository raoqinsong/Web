# NumberKeyboard 数字键盘
<div align="center">
  <img src="screenshot/basic.png" alt="外观">
</div>

## 功能
* 显示数字键盘
* 隐藏数字键盘

## 实现的组件
* [NumberKeyboard 数字键盘](https://www.youzanyun.com/zanui/vant#/zh-CN/component/number-keyboard) Vant 的组件。





