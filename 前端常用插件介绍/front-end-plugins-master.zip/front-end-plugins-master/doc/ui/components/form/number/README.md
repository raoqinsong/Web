# InputNumber 计数器
<div align="center">
  <img src="screenshot/basic.png" alt="外观">
  <img src="screenshot/btn-right.png" alt="外观">
</div>

## 功能
* 指定数字最小值
* 指定数字最大值
* 计数器步长
* 禁用状态

## 实现的组件
* [InputNumber 计数器](http://element-cn.eleme.io/#/zh-CN/component/input-number) Element 的组件。




