# Input 输入框 & 密码框 & 文本域
<div align="center">
  <img src="screenshot/basic.png" alt="外观"> <br>
  <img src="screenshot/area.png" alt="外观">
</div>

## 别名
Filed。

## 功能
* 只读状态
* 禁用状态
* 远程搜索(自动补全)
* 带图标
* 文本域
  * 行数
  * 列数

## 实现的组件
* [Input 输入框](http://element-cn.eleme.io/#/zh-CN/component/input) Element 的组件。




