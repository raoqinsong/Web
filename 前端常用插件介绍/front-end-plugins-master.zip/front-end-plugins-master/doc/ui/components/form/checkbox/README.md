# 多选框
<div align="center">
  <img src="screenshot/basic.png" alt="外观"><br>
</div>

## 别名
复选框。

## 功能
* 禁用状态

## 实现的组件
* [Checkbox 多选框](http://element-cn.eleme.io/#/zh-CN/component/checkbox) Element 的组件。


