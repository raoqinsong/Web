# 单选框
<div align="center">
  <img src="screenshot/basic.png" alt="外观"><br>
  <img src="screenshot/btn-style.png" alt="外观"><br>
</div>

## 功能
* 禁用状态

## 实现的组件
* [Radio 单选框](http://element-cn.eleme.io/#/zh-CN/component/radio) Element 的组件。


