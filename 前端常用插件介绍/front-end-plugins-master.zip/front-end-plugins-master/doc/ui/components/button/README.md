# 按钮
<div align="center">
  <img src="screenshot/basic.png" alt="外观">
</div>

## 功能
* 类型：primary,success,warn,info,error
* 大小：small,medium,large
* 禁用状态
* 幽灵/朴素按钮。外仅以线框示意轮廓，内只用文字示意功能，背景透出。
* 文字按钮。
* 图标按钮。
* 图标+文字。图标可以在左侧或右侧。

## 实现的组件
* [Button 按钮](http://element-cn.eleme.io/#/zh-CN/component/button) Element 的组件。