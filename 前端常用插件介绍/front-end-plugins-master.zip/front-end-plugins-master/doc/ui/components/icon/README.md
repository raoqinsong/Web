# Icon 图标
<div align="center">
  <img src="screenshot/basic.png" alt="外观">
</div>

## 别名
字体图标。

## 功能
* 能通过CSS控制大小。不会拉伸变现。
* 能通过CSS控制颜色。
* 能通过CSS控制背景。

## 实现的组件
* [Iconfont](http://www.iconfont.cn/) 阿里巴巴矢量图标库。
* [Icon 图标](http://element-cn.eleme.io/#/zh-CN/component/icon) Element 的组件。



