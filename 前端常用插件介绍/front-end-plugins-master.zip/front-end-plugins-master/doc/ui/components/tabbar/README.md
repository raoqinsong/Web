# TabBar
<div align="center">
  <img src="screenshot/basic.png" alt="外观">
</div>

## 别名
底部选项卡，标签栏。

## 功能
* 图标配置。
* 文字配置。
* Tab 的点击回调。

## 实现的组件
* [Tabbar](https://www.youzanyun.com/zanui/vant#/zh-CN/component/tabbar) Vant 的组件。
* Tabbar Mint 的组件。
